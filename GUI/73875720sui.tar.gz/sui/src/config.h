#ifndef  CONFIG_H
#define  CONFIG_H

#pragma pack(4)

#define WINDOWS_WIDTH 240
#define WINDOWS_HEIGHT  64


#endif
