#ifndef WINDOW_LOGIN_H
#define WINDOW_LOGIN_H

int login();

#endif