#ifndef MESSAGEBOX_H
#define MESSAGEBOX_H


int messageBox(char *message);


#endif
