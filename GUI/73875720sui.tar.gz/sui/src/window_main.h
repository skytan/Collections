#ifndef  WINDOW_MAIN_H
#define  WINDOW_MAIN_H

#include "sui.h"
#include "config.h"
#include "perr.h"

void create_main_window();

#endif
