#ifndef WINDOW_GOODS_H
#define WINDOW_GOODS_H

#include "sui.h"

void goodsMainWindow();

void goodsSetWindow();

      
#endif
