#ifndef SMESSAGEBOX_H
#define SMESSAGEBOX_H

void messageBox(const char *str);

int yesNoBox(const char *str);

#endif
