#ifndef SWORDGB2312_H
#define SWORDGB2312_H

const char* get_gb2312_word(unsigned u);


#endif